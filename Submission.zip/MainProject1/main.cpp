#include <iostream>
#include <ctime>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <list>
#include <iterator>

using namespace std;

int main(int argc, char** argv)
{
    pid_t processID;
    pid_t wpid;
    int childincrement = 0;
    int parentID;
    list<pid_t> PIDlist;
    list<pid_t> parentIDList;
    list<string> programIDs;
    int childnum = int(*argv[1]);
    int childfinishcheck = 0;
    int status_ptr;
    char *args[] = { NULL };
  //  const char *programIDnames[5] = { "./test_1.exe", "./test_2.exe", "./test_3.exe", "./test_4.exe", "./test_5.exe"};
    
    const char *programIDnames[5] = { "./test_1", "./test_2", "./test_3", "./test_4", "./test_5"};
    const char *programIDnamesexp[5] = { "/test_1", "/test_2", "/test_3", "/test_4", "/test_5"};


    for (int increment = 0; increment < (childnum - 48); increment++)
    {
	
        processID = fork();

        childincrement++;
        // cout << "Process ID Following Fork:" << processID << "\n";

        // cout << "Child ID: " << getpid() << "\n";

        // cout << "Child ID: " << getppid() << "\n";
        
        if (processID < 0) {
        	cout << "Error";
        }

        else if (processID == 0)
        {
            printf("Started Child %d with PID %d\r\n", childincrement, getpid());
        
	    srand(time(0) + getpid());	
	    
            int randval = rand() % 5;
            
            PIDlist.push_back(getpid());

            execv(programIDnames[randval], args);
            
            exit(0);
            

        }
        
	 
    }
    	
    	
     	
    
    	while(wait(NULL) > 0);
                
        cout << "Parent ID is " << getppid() << "\n";

        


}
